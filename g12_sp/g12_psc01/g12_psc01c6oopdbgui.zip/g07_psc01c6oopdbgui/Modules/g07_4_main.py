from g07_3_gui_tkinter import main as gui_main


if __name__ == "__main__":
    gui_main()
