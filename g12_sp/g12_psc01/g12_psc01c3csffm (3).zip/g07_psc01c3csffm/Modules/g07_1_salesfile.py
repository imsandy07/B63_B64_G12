from pathlib import Path
import csv
from g07_1_salesinput import correct_data_types, is_valid_region

# Files configuration (keep your existing constants)
NAMING_CONVENTION = "sales_qn_yyyy_r.csv"
FILEPATH = Path(__file__).parent.parent.parent / 'psc01_files'
ALL_SALES = 'all_sales.csv'
ALL_SALES_COPY = 'all_sales_copy.csv'
IMPORTED_FILES = 'imported_files.txt'

def is_valid_filename_format(filename: str) -> bool:
    if len(filename) == len(NAMING_CONVENTION) and \
            filename[:7] == NAMING_CONVENTION[:7] and \
            filename[8] == NAMING_CONVENTION[8] and \
            filename[13] == NAMING_CONVENTION[-6] and \
            filename[-4:] == NAMING_CONVENTION[-4:]:
        return True
    return False

def get_region_code_from_filename(sales_filename: str) -> str:
    return sales_filename[sales_filename.rfind('.') - 1]

def already_imported(filepath_name: Path) -> bool:
    try:
        with open(FILEPATH / IMPORTED_FILES, 'r') as f:
            imported_files = [line.strip() for line in f.readlines()]
            return filepath_name.name in imported_files
    except FileNotFoundError:
        return False

def add_imported_file(filepath_name: Path) -> None:
    with open(FILEPATH / IMPORTED_FILES, 'a') as f:
        f.write(f"{filepath_name.name}\n")

def import_sales(filepath_name: Path, delimiter: str = ',') -> list:
    with open(filepath_name, newline='') as csvfile:
        reader = csv.reader(csvfile, delimiter=delimiter)
        filename = filepath_name.name
        region_code = filename[filename.rfind('.') - 1]
        imported_sales_list = []
        for amount_sales_date in reader:
            correct_data_types(amount_sales_date)  # Now properly imported
            amount, sales_date = amount_sales_date[0], amount_sales_date[1]
            data = {
                "amount": amount,
                "sales_date": sales_date,
                "region": region_code,
            }
            imported_sales_list.append(data)
        return imported_sales_list

def main():
    pass

if __name__ == '__main__':
    main()