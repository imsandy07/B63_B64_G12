from pathlib import Path
import csv
from g07_1_salesinput import (from_input1, from_input2,
                             cal_quarter, get_region_name,
                             has_bad_amount, has_bad_date, has_bad_data)
from g07_1_salesfile import (import_sales, is_valid_filename_format,
                            get_region_code_from_filename, is_valid_region,
                            already_imported, add_imported_file, correct_data_types)

FILEPATH = Path(__file__).parent.parent.parent / 'psc01_files'
ALL_SALES = 'all_sales.csv'
ALL_SALES_COPY = 'all_sales_copy.csv'
IMPORTED_FILES = 'imported_files.txt'

def view_sales(sales_list: list) -> bool:
    bad_data_flag = False
    if len(sales_list) == 0:  # sales_list could be [] or None
        print("No sales to view.")
    else: # not empty
        col1_w, col2_w, col3_w, col4_w, col5_w = 5, 15, 15, 15, 15  # column width
        total_w = col1_w + col2_w + col3_w + col4_w + col5_w
        print(f"{' ':{col1_w}}"
              f"{'Date':{col2_w}}"
              f"{'Quarter':{col3_w}}"
              f"{'Region':{col4_w}}"
              f"{'Amount':>{col5_w}}")
        print(horizontal_line := f"{'-' * total_w}")
        total = 0.0

        for idx, sales in enumerate(sales_list, start=1):
            if has_bad_data(sales):
                bad_data_flag = True
                num = f"{idx}.*"   # add period and asterisk
            else:
                num = f"{idx}."    # add period only

            amount = sales["amount"]
            if not has_bad_amount(sales):
                total += amount

            sales_date = sales["sales_date"]
            if has_bad_date(sales):
                bad_data_flag = True
                month = 0
            else:
                month = int(sales_date.split("-")[1])

            region = get_region_name(sales["region"])
            quarter = f"{cal_quarter(month)}"
            print(f"{num:<{col1_w}}"
                  f"{sales_date:{col2_w}}"
                  f"{quarter:<{col3_w}}"
                  f"{region:{col4_w}}"
                  f"{amount:>{col5_w}}")

        print(horizontal_line)
        print(f"{'TOTAL':{col1_w}}"
              f"{' ':{col2_w + col3_w + col4_w}}"
              f"{total:>{col5_w}}\n")
    return bad_data_flag

def add_sales1(sales_list: list) -> None:
    sales_list.append(data := from_input1())
    print(f"Sales for {data['sales_date']} is added.")

def add_sales2(sales_list: list) -> None:
    sales_list.append(data := from_input2())
    print(f"Sales for {data['sales_date']} is added.")

def import_all_sales() -> list:
    sales_list = []
    try:
        with open(FILEPATH / ALL_SALES, newline='') as csvfile:
            reader = csv.reader(csvfile)
            for line in reader:
                if len(line) > 0:
                    amount_sales_date = [line[0], line[1]]
                    region_code = line[2]
                    correct_data_types(amount_sales_date)
                    amount, sales_date = amount_sales_date[0], amount_sales_date[1]
                    data = {
                        "amount": amount,
                        "sales_date": sales_date,
                        "region": region_code,
                    }
                    sales_list.append(data)
    except FileNotFoundError:
        pass
    return sales_list

def import_sales_from_file(sales_list: list) -> None:
    filename = input("Enter name of file to import: ")
    filepath_name = FILEPATH / filename
    if not is_valid_filename_format(filename):
        print(f"Filename '{filename}' doesn't follow the expected format of sales_qn_yyyy_r.csv.")
    elif not is_valid_region(get_region_code_from_filename(filename)):
        print(f"Filename '{filename}' doesn't include one of the following region codes: ['w', 'm', 'c', 'e'].")
    elif already_imported(filepath_name):
        filename = filename.replace("\n", "")
        print(f"File '{filename}' has already been imported.")
    else:
        imported_sales_list = import_sales(filepath_name)
        if imported_sales_list is None:
            print(f"Fail to import sales from '{filename}'.")
        else:
            bad_data_flag = view_sales(imported_sales_list)
            if bad_data_flag:
                print(f"File '{filename}' contains bad data.\n"
                      "Please correct the data in the file and try again.")
            elif len(imported_sales_list) > 0:
                sales_list.extend(imported_sales_list)
                print("Imported sales added to list.")
                add_imported_file(filepath_name)

def save_all_sales(sales_list, delimiter: str=',') -> None:
    with open(FILEPATH / ALL_SALES, 'w', newline='') as csvfile:
        writer = csv.writer(csvfile, delimiter=delimiter)
        for sale in sales_list:
            writer.writerow([sale['amount'], sale['sales_date'], sale['region']])

def initialize_content_of_files(delimiter: str=',') -> None:
    with open(FILEPATH / ALL_SALES_COPY, 'r') as src, open(FILEPATH / ALL_SALES, 'w') as dst:
        dst.write(src.read())
    with open(FILEPATH / IMPORTED_FILES, 'w') as f:
        f.write("")

def main():
    pass

if __name__ == '__main__':
    main()