from g07_2_salesmanager import view_sales, add_sales1, add_sales2, import_sales, import_all_sales, save_all_sales, initialize_content_of_files

def display_title() -> None:
    print("SALES DATA IMPORTER\n")

def display_menu() -> None:
    cmd_format = "6"
    print("COMMAND MENU",
          f"{'view':{cmd_format}} - View all sales",
          f"{'add1':{cmd_format}} - Add sales by typing sales, year, month, day, and region",
          f"{'add2':{cmd_format}} - Add sales by typing sales, date (YYYY-MM-DD), and region",
          f"{'import':{cmd_format}} - Import sales from file",
          f"{'menu':{cmd_format}} - Show menu",
          f"{'exit':{cmd_format}} - Exit program", sep='\n', end='\n')

def execute_command() -> None:
    initialize_content_of_files()
    sales_list = import_all_sales()

    commands = {"import": import_sales,
                "add1": add_sales1,
                "add2": add_sales2,
                "view": view_sales,
                "menu": display_menu,
                }
    while True:
        action = input("\nPlease enter a command: ").strip().lower()
        if action == "exit":
            save_all_sales(sales_list)
            print("Saved sales records.")
            break
        if action == "import":
            commands[action](sales_list)
        elif action in ("add1", "add2"):
            commands[action](sales_list)
        elif action == "view":
            commands[action](sales_list)
        elif action == "menu":
            commands[action]()
        else:
            print("Invalid command. Please try again.\n")
            display_menu()

def main():
    display_title()
    display_menu()
    execute_command()
    print("Bye!")

if __name__ == '__main__':
    main()