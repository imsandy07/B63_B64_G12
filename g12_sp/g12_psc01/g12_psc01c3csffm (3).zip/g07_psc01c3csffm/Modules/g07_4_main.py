from g07_start_psc01c3csffm import main

if __name__ == '__main__':
    main()